from django.apps import AppConfig


class AgriConfig(AppConfig):
    name = 'agri'
